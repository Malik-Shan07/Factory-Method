/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package FM_Example_1;

/**
 *
 * @author malik
 */
public interface Button {
    void render();
    void onClick();
}
