/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Github_Example;

/**
 *
 * @author malik
 */
public class Square implements Shape{

	@Override
	public void draw() {
		System.out.println("square is drawn ⏹️");
		
	}
}
